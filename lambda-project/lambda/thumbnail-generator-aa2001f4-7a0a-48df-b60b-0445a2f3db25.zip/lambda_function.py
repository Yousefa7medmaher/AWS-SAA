import boto3
from PIL import Image
import io
import os

s3 = boto3.client("s3")

# Destination bucket name from Lambda Environment Variable
DEST_BUCKET = os.environ["DEST_BUCKET"]


def lambda_handler(event, context):

    # Get source bucket and uploaded object key
    source_bucket = event["Records"][0]["s3"]["bucket"]["name"]
    key = event["Records"][0]["s3"]["object"]["key"]

    # Download image from S3
    response = s3.get_object(
        Bucket=source_bucket,
        Key=key
    )

    image = Image.open(io.BytesIO(response["Body"].read()))

    # Resize while keeping aspect ratio
    image.thumbnail((100, 100))

    # JPEG supports only RGB
    if image.mode != "RGB":
        image = image.convert("RGB")

    # Save thumbnail into memory
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG")
    buffer.seek(0)

    # Upload thumbnail to destination bucket
    s3.put_object(
        Bucket=DEST_BUCKET,
        Key=f"thumb-{key}",
        Body=buffer,
        ContentType="image/jpeg"
    )

    return {
        "statusCode": 200,
        "body": f"Thumbnail created successfully: thumb-{key}"
    }